# The World Atlas of Language Structures Online

[![Build Status](https://travis-ci.org/cldf-datasets/wals.svg?branch=master)](https://travis-ci.org/cldf-datasets/wals)

Cite the source dataset as

> Dryer, Matthew S. & Haspelmath, Martin (eds.) 2013. The World Atlas of Language Structures Online. Leipzig: Max Planck Institute for Evolutionary Anthropology. (Available online at https://wals.info)

This dataset is licensed under a CC-BY-4.0 license

Available online at https://wals.info
